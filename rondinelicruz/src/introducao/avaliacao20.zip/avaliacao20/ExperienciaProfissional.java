package introducao.avaliacao20;

public class ExperienciaProfissional {

    private String nome;
    private String anoConclusao;
   
   
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getAnoConclusao() {
        return anoConclusao;
    }
    public void setAnoConclusao(String anoConclusao) {
        this.anoConclusao = anoConclusao;
    }
    public float contarNumExperienciasProfissionais() {
        return 0;
    }

    
    
}
